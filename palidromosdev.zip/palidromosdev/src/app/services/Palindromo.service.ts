import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Palindromo} from '../interfaces/Palindromo';
import {Contadores} from '../interfaces/contadores';
@Injectable({
  providedIn: 'root'
})

export class PalindromoService {
 
  Api='http://localhost/prueba_1024482240/api-rest-palindromo-back/';
  constructor(private htppClient:HttpClient) {}
  get() {
    return this.htppClient.get(this.Api+'list');
  }
  save(param){
    const headers=new HttpHeaders(  {'Content-Type':'application/x-www-form-urlencoded'});
    return this.htppClient.post(this.Api+'save',param,{headers:headers});
  }

   contadoresGet() {
    return this.htppClient.get(this.Api+'contadores');
  }
  


}
