export interface Contadores{
total:number;
estado:number;

}