export interface  Palindromo{
id:number;
frase:string;
estado:number;

}