import { Component, OnInit } from '@angular/core';
import {PalindromoService} from '../services/palindromo.service';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Palindromo} from '../interfaces/Palindromo';
import {Contadores} from '../interfaces/contadores';
@Component({
  selector: 'app-palindromo',
  templateUrl: './Palindromo.component.html',
  styleUrls: ['./Palindromo.component.css']
})
export class PalindromoComponent implements OnInit {
   contadores:Contadores[];
   palindromo:Palindromo[];
   dtoption: any;
   constructor(private palindromoService:PalindromoService,private httpClient:HttpClient) {
    
  this.getpalidromo();
  this.getContador(); 
    }

  ngOnInit() {
  }

  getpalidromo():void{

    let elem: any;
  this.palindromoService.get().subscribe( (data:Palindromo[])=>{this.palindromo=data;
    //console.log(data)
  $(document).ready(function(){
 
 this.dtoption={
   dom:'Bfrtip',
   buttons:[{
                extend:    'excelHtml5',
                text:      '<img src="https://img.icons8.com/color/18/000000/ms-excel.png" >',
                titleAttr: 'Excel',
                
            },
         
            {
                extend:    'pdfHtml5',
                text:      '<img src="https://img.icons8.com/color/18/000000/pdf.png">',
                titleAttr: 'PDF'
            }]
 }
 elem = $("#table");
 elem.DataTable(this.dtoption);


  }) 
  
 
  },(error)=>{
      console.log(error)
    });

  }

getContador():void{
this.palindromoService.contadoresGet().subscribe((data:Contadores[])=>{this.contadores=data;
     },(error)=>{
      console.log(error)
    });

  }



  savePalindromo(){
    if ($("#frase").val()=="") {
      alert('este  campo es requerido');
      return  false;
    }
    let elem:any;
    var parametros =  $("#polindromas").serialize();
    //console.log(parametros);
this.palindromoService.save(parametros).subscribe( (data)=>{alert(data['respuesta']);
  $("#frase").val("");
 elem=$("#table");
 elem.DataTable().destroy();
 this.getpalidromo();
   this.getContador(); 
},(error)=>{
     console.log(error)
   });

  }

  

}
