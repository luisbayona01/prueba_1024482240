import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Component } from '@angular/core';

import * as $ from 'jquery';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { PalindromoComponent } from './palindromo/Palindromo.component';


@NgModule({
  declarations: [
    AppComponent,
    PalindromoComponent,


  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
